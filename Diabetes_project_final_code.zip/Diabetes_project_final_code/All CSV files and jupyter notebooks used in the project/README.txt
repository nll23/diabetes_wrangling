
---Part 1 & 2 Diabetes Prevalence data and US mortality data------
----There are 3 source csv files related to this part of project
------API_SH.STA.DIAB.ZS_DS2_en_csv_v2_10136460.csv
------API_SP.POP.TOTL_DS2_en_csv_v2_10134466.csv
------Europe.csv (PDF scraped output)
------US MORTALITY.csv
----There are 2 output csv files produced for this which are the source files for the julia part
------diabetes_population.csv
------final_country_df
----Diabetes_project_part1_R.ipynb file contains the R part
----Diabetes _project_part2_Julia.ipynb contains the Julia part


---Part 3 Diabetes Hospitalisation data for US
----There are seven "csv" files related to the work on the US diabetic hospitalisation data, which are:
  -the "diabetic_data.csv" which is the source data that we worked on;
  -the "IDs_mapping" which is the source metadata which we later wrangled into three metadata tables
  -the "diabetes.csv" which is the cleaned version of the "diabetic_data.csv" file where we got from the 
    wrangling work, this file is also the start point for the working in julia in this part
  -the "attributes.csv" which contains the detailed information about the attributes in the main table
  -the "admission_source.csv" which is the metadata table for the "diabetes.csv" file containing the 
   admission_source_ids and the associated admission_sources
  -the "admission_type.csv" which is the metadata table for the "diabetes.csv" file containing the 
   admission_type_ids and the associated admission_types
  -the "discharge_disposition.csv" which is the metadata table for the "diabetes.csv" file containing the 
   discharge_disposition_ids and the associated discharge_dispositions

--The "Diabetes_project_part3_R.ipynb" contains the code for the working in r on the US diabetic hospitalisation data.

--The "Diabetes_project_part4_Julia.ipynb" contains the code for the woking in julia on the US diabetic hospitalisation data.